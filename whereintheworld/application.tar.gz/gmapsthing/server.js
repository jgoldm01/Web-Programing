// Initialization
var express = require('express');
var bodyParser = require('body-parser');
var validator = require('validator'); // See documentation at https://github.com/chriso/validator.js
var http = require("http");
var app = express();
// See https://stackoverflow.com/questions/5710358/how-to-get-post-query-in-express-node-js
app.use(bodyParser.json());
// See https://stackoverflow.com/questions/25471856/express-throws-error-as-body-parser-deprecated-undefined-extended
app.use(bodyParser.urlencoded({ extended: true }));

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://heroku:_x7YdthsJPDMwjKhHS3WgRTvYRA6qCzcFeXIzEX9w32a-u6Nxnoss2psyfet7YvLXYU0DgR67atixUYIYGm45Q@dogen.mongohq.com:10010/app31716410'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');

var db = mongo.Db.connect(mongoUri, function (err, databaseConnection) {
	if (!err) {
  	db = databaseConnection;
  	// console.log("fuck yeah")
  	// db.collection('peoples', function(er, collection) {
			// collection.insert({name:"me"}, function(err, saved) {
  	// 		//console.log(saved)
  	// 	});
  	// 	collection.find().toArray(function(err, cursor) {
   //      result = {characters:[], students:[]}
  	// 		for (var count = 0; count < cursor.length; count++) {
   //        //console.log(cursor[count])
   //        result.students[count] = cursor[count]
  	// 		}
   //      console.log(JSON.stringify(result))
  	// 	});
  	// });
	} 
});

// app.all('/sendLocation', function(req, res) {
//   req.header("Access-Control-Allow-Origin", "*");
//   req.header("Access-Control-Allow-Headers", "X-Requested-With");
// });

app.post('/sendLocation', function(request, res) {
	// console.log("oh they here papi")
  login = request.body.login
  lat = request.body.lat
  lng = request.body.lng
  date = Date()
  if (login != null && lat != null && lng != null) {
    toInsert = {"login":login, "lat":lat, "lng":lng, "created_at":date}
  	res.setHeader("Access-Control-Allow-Origin", "*")
    res.setHeader("Content-Type", "application/json")
  	//res.send({"name":"me"});
    db.collection('peoples', function(er, collection) {
      collection.insert(toInsert, function(err, saved){

      });
      collection.find().toArray(function(err, cursor) {
        result = {characters:[], students:[]}
        dbIndex = cursor.length - 1
        for (var count = 0; count < cursor.length && count < 100; count++) {
          result.students[count] = cursor[dbIndex]
          dbIndex--
        }
        res.send(JSON.stringify(result))
      });
    });
  }
});

app.get('/locations.json', function(request, response) {
  login = request.query.login
  loginLog = []
  db.collection('peoples', function(er, collection) {
    collection.find({"login":login}).toArray(function(err, cursor) {
      dbIndex = cursor.length - 1
      for (var count = 0; count < cursor.length; count++) {
        loginLog[count] = cursor[dbIndex]
        dbIndex--
      }
      response.send(JSON.stringify(loginLog))
    });
  });
});

app.get('/', function (request, response) {
  response.set('Content-Type', 'text/html');
  // response.send('<p>Hey, it works!</p>');
  var indexPage = '';
  db.collection('peoples', function(er, collection) {
    collection.find().toArray(function(err, cursor) {
      indexPage += "<!DOCTYPE HTML><html><head><title>Where are the peoples</title></head><body><h1>Here are the peoples</h1>";
      dbIndex = cursor.length - 1
      for(var count = 0; count < cursor.length; count++){
        //console.log(cursor[dbIndex].login)
        indexPage += "<p>Login: " + cursor[dbIndex].login + " latitude: " 
                  + cursor[dbIndex].lat + " longitude: " + cursor[dbIndex].lng 
                  + " created at: " + cursor[dbIndex].created_at + "</p>"
        dbIndex--
      }
      response.send(indexPage)
    });
  });
});

app.get('/redline.json', function(request, response) {
  var data = '';
  http.get("http://developer.mbta.com/lib/rthr/red.json", function(apiresponse) {
    apiresponse.on('data', function(chunk) {
      data += chunk;
    });
    apiresponse.on('end', function() {
      response.send(data);
    });
  }).on('error', function(error) {
    response.send(500);
  });
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);